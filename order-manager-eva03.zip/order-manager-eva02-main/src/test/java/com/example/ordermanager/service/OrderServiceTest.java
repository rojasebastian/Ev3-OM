package com.example.ordermanager.service;

import com.example.ordermanager.dto.AddItemRequest;
import com.example.ordermanager.dto.CreateOrderRequest;
import com.example.ordermanager.exception.InvalidOrderStateException;
import com.example.ordermanager.exception.OrderNotFoundException;
import com.example.ordermanager.model.Order;
import com.example.ordermanager.model.OrderStatus;
import com.example.ordermanager.repository.OrderRepository;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import com.example.ordermanager.observability.OrderMetrics;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("OrderService - Pruebas unitarias")
class OrderServiceTest {

    @Mock
    private OrderRepository repository;

    // Registro de métricas real (en memoria): permite verificar los contadores de negocio.
    private final SimpleMeterRegistry meterRegistry = new SimpleMeterRegistry();

    @Spy
    private OrderMetrics metrics = new OrderMetrics(meterRegistry);

    @InjectMocks
    private OrderService service;

    @Test
    @DisplayName("getAllOrders: retorna lista completa")
    void shouldReturnAllOrders() {
        when(repository.findAll()).thenReturn(List.of(new Order("A"), new Order("B")));
        assertEquals(2, service.getAllOrders().size());
    }

    @Test
    @DisplayName("getOrderById: retorna pedido si existe")
    void shouldReturnOrderById() {
        Order order = new Order("Juan");
        order.setId(1L);
        when(repository.findById(1L)).thenReturn(Optional.of(order));

        Order result = service.getOrderById(1L);
        assertEquals("Juan", result.getCustomerName());
    }

    @Test
    @DisplayName("getOrderById: lanza excepción si no existe")
    void shouldThrowWhenOrderNotFound() {
        when(repository.findById(99L)).thenReturn(Optional.empty());
        assertThrows(OrderNotFoundException.class, () -> service.getOrderById(99L));
    }

    @Test
    @DisplayName("createOrder: crea pedido con ítems")
    void shouldCreateOrderWithItems() {
        when(repository.save(any(Order.class))).thenAnswer(i -> i.getArgument(0));

        CreateOrderRequest req = new CreateOrderRequest();
        req.setCustomerName("Juan");
        AddItemRequest item = new AddItemRequest("Laptop", 1, new BigDecimal("1200.00"));
        req.setItems(List.of(item));

        Order result = service.createOrder(req);

        assertEquals("Juan", result.getCustomerName());
        assertEquals(1, result.getItems().size());
        assertEquals(new BigDecimal("1200.00"), result.getTotalAmount());
        assertEquals(OrderStatus.PENDING, result.getStatus());
    }

    @Test
    @DisplayName("createOrder: crea pedido vacío")
    void shouldCreateEmptyOrder() {
        when(repository.save(any(Order.class))).thenAnswer(i -> i.getArgument(0));

        CreateOrderRequest req = new CreateOrderRequest();
        req.setCustomerName("Juan");

        Order result = service.createOrder(req);

        assertEquals(0, result.getItems().size());
        assertEquals(BigDecimal.ZERO, result.getTotalAmount());
    }

    @Test
    @DisplayName("addItem: agrega ítem a pedido PENDING")
    void shouldAddItemToPendingOrder() {
        Order order = new Order("Juan");
        order.setId(1L);
        when(repository.findById(1L)).thenReturn(Optional.of(order));
        when(repository.save(any(Order.class))).thenAnswer(i -> i.getArgument(0));

        AddItemRequest req = new AddItemRequest("Mouse", 2, new BigDecimal("25.50"));
        Order result = service.addItem(1L, req);

        assertEquals(1, result.getItems().size());
        assertEquals(new BigDecimal("51.00"), result.getTotalAmount());
    }

    @Test
    @DisplayName("addItem: falla si NO está PENDING")
    void shouldFailWhenAddingItemToConfirmedOrder() {
        Order order = new Order("Juan");
        order.setId(1L);
        order.setStatus(OrderStatus.CONFIRMED);
        when(repository.findById(1L)).thenReturn(Optional.of(order));

        AddItemRequest req = new AddItemRequest("Mouse", 1, new BigDecimal("25.00"));

        assertThrows(InvalidOrderStateException.class, () -> service.addItem(1L, req));
        verify(repository, never()).save(any(Order.class));
    }

    @Test
    @DisplayName("confirmOrder: PENDING → CONFIRMED")
    void shouldConfirmPendingOrder() {
        Order order = new Order("Juan");
        order.setId(1L);
        when(repository.findById(1L)).thenReturn(Optional.of(order));
        when(repository.save(any(Order.class))).thenAnswer(i -> i.getArgument(0));

        Order result = service.confirmOrder(1L);
        assertEquals(OrderStatus.CONFIRMED, result.getStatus());
    }

    @Test
    @DisplayName("confirmOrder: falla si no está PENDING")
    void shouldFailConfirmingShippedOrder() {
        Order order = new Order("Juan");
        order.setId(1L);
        order.setStatus(OrderStatus.SHIPPED);
        when(repository.findById(1L)).thenReturn(Optional.of(order));

        assertThrows(InvalidOrderStateException.class, () -> service.confirmOrder(1L));
    }

    @Test
    @DisplayName("shipOrder: CONFIRMED → SHIPPED")
    void shouldShipConfirmedOrder() {
        Order order = new Order("Juan");
        order.setId(1L);
        order.setStatus(OrderStatus.CONFIRMED);
        when(repository.findById(1L)).thenReturn(Optional.of(order));
        when(repository.save(any(Order.class))).thenAnswer(i -> i.getArgument(0));

        Order result = service.shipOrder(1L);
        assertEquals(OrderStatus.SHIPPED, result.getStatus());
    }

    @Test
    @DisplayName("deliverOrder: SHIPPED → DELIVERED")
    void shouldDeliverShippedOrder() {
        Order order = new Order("Juan");
        order.setId(1L);
        order.setStatus(OrderStatus.SHIPPED);
        when(repository.findById(1L)).thenReturn(Optional.of(order));
        when(repository.save(any(Order.class))).thenAnswer(i -> i.getArgument(0));

        Order result = service.deliverOrder(1L);
        assertEquals(OrderStatus.DELIVERED, result.getStatus());
    }

    @Test
    @DisplayName("cancelOrder: PENDING → CANCELLED")
    void shouldCancelPendingOrder() {
        Order order = new Order("Juan");
        order.setId(1L);
        when(repository.findById(1L)).thenReturn(Optional.of(order));
        when(repository.save(any(Order.class))).thenAnswer(i -> i.getArgument(0));

        Order result = service.cancelOrder(1L);
        assertEquals(OrderStatus.CANCELLED, result.getStatus());
    }

    @Test
    @DisplayName("cancelOrder: falla si ya está DELIVERED")
    void shouldFailCancellingDeliveredOrder() {
        Order order = new Order("Juan");
        order.setId(1L);
        order.setStatus(OrderStatus.DELIVERED);
        when(repository.findById(1L)).thenReturn(Optional.of(order));

        assertThrows(InvalidOrderStateException.class, () -> service.cancelOrder(1L));
    }

    @Test
    @DisplayName("cancelOrder: falla si ya está CANCELLED")
    void shouldFailCancellingCancelledOrder() {
        Order order = new Order("Juan");
        order.setId(1L);
        order.setStatus(OrderStatus.CANCELLED);
        when(repository.findById(1L)).thenReturn(Optional.of(order));

        assertThrows(InvalidOrderStateException.class, () -> service.cancelOrder(1L));
    }

    @Test
    @DisplayName("deleteOrder: elimina si existe")
    void shouldDeleteOrder() {
        when(repository.existsById(1L)).thenReturn(true);
        service.deleteOrder(1L);
        verify(repository).deleteById(1L);
    }

    @Test
    @DisplayName("deleteOrder: falla si no existe")
    void shouldFailDeletingNonExistent() {
        when(repository.existsById(99L)).thenReturn(false);
        assertThrows(OrderNotFoundException.class, () -> service.deleteOrder(99L));
    }

    // ============================================================
    // Observabilidad (EV3): las operaciones publican métricas de negocio
    // ============================================================

    @Test
    @DisplayName("métricas: createOrder incrementa orders.created")
    void shouldCountCreatedOrders() {
        when(repository.save(any(Order.class))).thenAnswer(i -> i.getArgument(0));
        CreateOrderRequest req = new CreateOrderRequest();
        req.setCustomerName("Juan");

        service.createOrder(req);
        service.createOrder(req);

        assertEquals(2.0, meterRegistry.get("orders.created").counter().count());
    }

    @Test
    @DisplayName("métricas: una transición válida incrementa orders.status.changed")
    void shouldCountStatusChanges() {
        Order order = new Order("Juan");
        order.setId(1L);
        when(repository.findById(1L)).thenReturn(Optional.of(order));
        when(repository.save(any(Order.class))).thenAnswer(i -> i.getArgument(0));

        service.confirmOrder(1L);

        assertEquals(1.0, meterRegistry.get("orders.status.changed")
                .tag("status", "CONFIRMED").counter().count());
    }

    @Test
    @DisplayName("métricas: una transición inválida incrementa orders.invalid.transition")
    void shouldCountInvalidTransitions() {
        Order order = new Order("Juan");
        order.setId(1L);
        order.setStatus(OrderStatus.SHIPPED);
        when(repository.findById(1L)).thenReturn(Optional.of(order));

        assertThrows(InvalidOrderStateException.class, () -> service.confirmOrder(1L));

        assertEquals(1.0, meterRegistry.get("orders.invalid.transition").counter().count());
    }
}
